package com.example.quizproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
