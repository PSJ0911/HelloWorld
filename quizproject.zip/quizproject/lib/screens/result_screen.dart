import 'package:flutter/material.dart';
import 'quiz_screen.dart';
import 'wrong_note_screen.dart';
import 'global.dart';

class ResultScreen extends StatelessWidget {
  final int score;
  final int total;

  const ResultScreen({
    super.key,
    required this.score,
    required this.total,
  });

  @override
  Widget build(BuildContext context) {
    final percentage = (score / total * 100).toStringAsFixed(1);

    return Scaffold(
      appBar: AppBar(title: const Text("퀴즈 결과")),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24.0),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Text("퀴즈 완료!", style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold)),
              const SizedBox(height: 20),
              Text("당신의 점수는 $score / $total", style: const TextStyle(fontSize: 22)),
              const SizedBox(height: 10),
              Text("정답률: $percentage%", style: const TextStyle(fontSize: 18, color: Colors.grey)),
              const SizedBox(height: 40),
              ElevatedButton(
                onPressed: () {
                  Navigator.pushReplacement(
                    context,
                    MaterialPageRoute(builder: (_) => const QuizScreen(useTimer: false)),
                  );
                },
                child: const Text("다시 시작하기"),
              ),
              const SizedBox(height: 16),
              if (globalWrongQuestions.isNotEmpty)
                ElevatedButton(
                  onPressed: () {
                    Navigator.pushReplacement(
                      context,
                      MaterialPageRoute(
                        builder: (_) => WrongNoteScreen(wrongQuestions: globalWrongQuestions),
                      ),
                    );
                  },
                  child: const Text("오답 복습하기"),
                ),
            ],
          ),
        ),
      ),
    );
  }
}