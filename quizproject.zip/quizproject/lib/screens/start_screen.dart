import 'package:flutter/material.dart';
import 'quiz_screen.dart';
import 'wrong_note_screen.dart';
import 'settings_screen.dart';
import '../models/question.dart'; //
import '../screens/global.dart'; //

class StartScreen extends StatefulWidget {
  const StartScreen({super.key});

  @override
  State<StartScreen> createState() => _StartScreenState();
}

class _StartScreenState extends State<StartScreen> {
  bool _useTimer = true;

  void _openSettings() async {
    final result = await Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => SettingsScreen(useTimer: _useTimer),
      ),
    );

    if (result != null && result is bool) {
      setState(() {
        _useTimer = result;
      });
    }
  }

  void _openWrongNote() {
    if (globalWrongQuestions.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text("저장된 오답이 없습니다.")),
      );
      return;
    }

    Navigator.push(
      context,
      MaterialPageRoute(
        builder: (_) => WrongNoteScreen(wrongQuestions: globalWrongQuestions),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("운전면허 퀴즈")),
      body: Center(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Image.asset(
                'assets/images/license_exam_pass.png',
                height: 160,
              ),
              const Text(
                "무엇을 하시겠습니까?",
                style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 30),
              Wrap(
                spacing: 16,
                runSpacing: 16,
                alignment: WrapAlignment.center,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.play_arrow),
                    label: const Text("퀴즈"),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(120, 48),
                    ),
                    onPressed: () {
                      Navigator.push(
                        context,
                        MaterialPageRoute(
                          builder: (_) => QuizScreen(useTimer: _useTimer),
                        ),
                      );
                    },
                  ),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.note),
                    label: const Text("오답노트"),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(120, 48),
                    ),
                    onPressed: _openWrongNote,
                  ),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.settings),
                    label: const Text("설정"),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(120, 48),
                    ),
                    onPressed: _openSettings,
                  ),
                  ElevatedButton.icon(
                    icon: const Icon(Icons.info),
                    label: const Text("앱 정보"),
                    style: ElevatedButton.styleFrom(
                      minimumSize: const Size(120, 48),
                    ),
                    onPressed: () {
                      showAboutDialog(
                        context: context,
                        applicationName: '운전면허 퀴즈 앱',
                        applicationVersion: 'v1.0',
                        children: const [
                          Text("Flutter로 만든 연습용 앱입니다."),
                        ],
                      );
                    },
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}