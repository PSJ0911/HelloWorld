import '../models/question.dart';

List<Question> globalWrongQuestions = [];