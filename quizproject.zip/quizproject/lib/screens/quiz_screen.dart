import 'dart:async';
import 'package:flutter/material.dart';
import '../models/question.dart';
import '../widgets/question_card.dart';
import 'global.dart';
import 'result_screen.dart';

class QuizScreen extends StatefulWidget {
  final bool useTimer;

  const QuizScreen({super.key, required this.useTimer});

  @override
  State<QuizScreen> createState() => _QuizScreenState();
}

class _QuizScreenState extends State<QuizScreen> {
  final List<Question> _questions = [
    Question(
      text: "1. 신호등이 빨간불일 때 어떻게 해야 하나요?",
      options: ["서행", "정지", "가속", "경적"],
      answerIndex: 1,
      explanation: "빨간불은 정지 신호이므로 반드시 멈춰야 합니다.",
    ),
    Question(
      text: "2. 비가 오는 날 운전 시 주의사항은?",
      options: ["속도를 높인다", "전조등을 끈다", "속도를 줄인다", "창문을 연다"],
      answerIndex: 2,
      explanation: "비 오는 날에는 시야와 제동력이 나빠지므로 속도를 줄이는 것이 안전합니다.",
    ),
    Question(
      text: "3. 교차로에서 좌회전할 때 어디를 가장 먼저 확인해야 하나요?",
      options: ["좌측 도로", "신호등", "보행자", "반대편 차량"],
      answerIndex: 2,
      explanation: "보행자와의 충돌을 방지하기 위해 가장 먼저 보행자를 확인해야 합니다.",
    ),
    Question(
      text: "4. 고속도로에서 최소 속도는?",
      options: ["30km/h", "50km/h", "60km/h", "80km/h"],
      answerIndex: 2,
      explanation: "고속도로에서는 원활한 소통을 위해 최소 60km/h 이상으로 주행해야 합니다.",
    ),
    Question(
      text: "5. 주행 중 핸드폰 사용은?",
      options: ["가능", "스피커폰만 가능", "금지", "정차 시만 가능"],
      answerIndex: 2,
      explanation: "운전 중 핸드폰 사용은 사고 위험이 높아지므로 금지되어 있습니다.",
    ),
    Question(
      text: "6. 도로에 보행자가 있을 때는?",
      options: ["경적을 울린다", "속도를 줄이고 양보", "무시하고 통과", "라이트를 깜빡인다"],
      answerIndex: 1,
      explanation: "보행자가 우선이므로 속도를 줄이고 양보해야 합니다.",
    ),
    Question(
      text: "7. 운전 중 졸음이 오면?",
      options: ["창문을 연다", "속도를 줄인다", "휴게소에 정차", "커피를 마신다"],
      answerIndex: 2,
      explanation: "졸음운전은 매우 위험하므로 반드시 휴게소나 안전한 장소에 정차해야 합니다.",
    ),
    Question(
      text: "8. 주정차 금지 구역은?",
      options: ["횡단보도", "골목길", "상가 앞", "공터"],
      answerIndex: 0,
      explanation: "횡단보도는 보행자의 안전을 위해 주정차가 금지되어 있습니다.",
    ),
    Question(
      text: "9. 교차로에서 우회전 시 유의사항은?",
      options: ["직진 차량", "보행자", "좌회전 차량", "주차 차량"],
      answerIndex: 1,
      explanation: "우회전 시 보행자와 충돌할 위험이 있으므로 반드시 보행자를 우선 확인해야 합니다.",
    ),
    Question(
      text: "10. 안전벨트 착용 의무 대상은?",
      options: ["운전자만", "운전자와 동승자", "고령자만", "아이만"],
      answerIndex: 1,
      explanation: "모든 차량 탑승자는 안전벨트를 착용해야 합니다.",
    ),
  ];
  int _currentIndex = 0;
  int? _selectedIndex;
  bool _answered = false;
  int _score = 0;

  Timer? _timer;
  int _timeLeft = 20;

  @override
  void initState() {
    super.initState();
    globalWrongQuestions.clear(); // 오답 초기화
    if (widget.useTimer) {
      _startTimer();
    }
  }

  void _startTimer() {
    _timeLeft = 20;
    _timer?.cancel();
    _timer = Timer.periodic(const Duration(seconds: 1), (timer) {
      setState(() {
        if (_timeLeft > 0) {
          _timeLeft--;
        } else {
          _handleTimeout();
        }
      });
    });
  }

  void _handleTimeout() {
    _timer?.cancel();
    if (!_answered) {
      globalWrongQuestions.add(_questions[_currentIndex]);
      setState(() {
        _answered = true;
        _selectedIndex = null;
      });
    }
  }

  void _selectAnswer(int index) {
    if (_answered) return;
    _timer?.cancel();

    setState(() {
      _selectedIndex = index;
      _answered = true;

      if (index == _questions[_currentIndex].answerIndex) {
        _score++;
      } else {
        globalWrongQuestions.add(_questions[_currentIndex]);
      }
    });
  }

  void _nextQuestion() {
    if (_currentIndex < _questions.length - 1) {
      setState(() {
        _currentIndex++;
        _selectedIndex = null;
        _answered = false;
      });
      if (widget.useTimer) _startTimer();
    } else {
      _timer?.cancel();
      Navigator.pushReplacement(
        context,
        MaterialPageRoute(
          builder: (_) => ResultScreen(
            score: _score,
            total: _questions.length,
          ),
        ),
      );
    }
  }

  @override
  void dispose() {
    _timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final question = _questions[_currentIndex];
    final progress = (_currentIndex + 1) / _questions.length;
    final timerProgress = _timeLeft / 20; // 20초 기준

    return Scaffold(
      appBar: AppBar(
        title: Text("문제 ${_currentIndex + 1} / ${_questions.length}"),
      ),
      body: Column(
        children: [
          if (widget.useTimer)
            Align(
              alignment: Alignment.topLeft,
              child: Padding(
                padding: const EdgeInsets.all(12),
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    SizedBox(
                      height: 50,
                      width: 50,
                      child: CircularProgressIndicator(
                        value: timerProgress,
                        strokeWidth: 5,
                        backgroundColor: Colors.grey[300],
                        valueColor: AlwaysStoppedAnimation<Color>(
                          _timeLeft <= 5 ? Colors.red : Colors.blue,
                        ),
                      ),
                    ),
                    Text(
                      '$_timeLeft',
                      style: TextStyle(
                        fontSize: 16,
                        fontWeight: FontWeight.bold,
                        color: _timeLeft <= 5 ? Colors.red : Colors.black,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
            child: LinearProgressIndicator(
              value: progress,
              minHeight: 8,
              backgroundColor: Colors.grey[300],
              valueColor: AlwaysStoppedAnimation<Color>(
                Colors.blue,
              ),
            ),
          ),
          Expanded(
            child: Padding(
              padding: const EdgeInsets.all(16.0),
              child: QuestionCard(
                question: question,
                selectedIndex: _selectedIndex,
                answered: _answered,
                onSelect: _selectAnswer,
              ),
            ),
          ),
        ],
      ),
      floatingActionButton: _answered
          ? FloatingActionButton(
        onPressed: _nextQuestion,
        child: const Icon(Icons.arrow_forward),
      )
          : null,
    );
  }
}