import 'package:flutter/material.dart';
import '../models/question.dart';
import '../widgets/question_card.dart';
import 'quiz_screen.dart';

class WrongNoteScreen extends StatefulWidget {
  final List<Question> wrongQuestions;

  const WrongNoteScreen({super.key, required this.wrongQuestions});

  @override
  State<WrongNoteScreen> createState() => _WrongNoteScreenState();
}

class _WrongNoteScreenState extends State<WrongNoteScreen> {
  int _currentIndex = 0;
  int? _selectedIndex;
  bool _answered = false;

  void _selectAnswer(int index) {
    if (_answered) return;

    setState(() {
      _selectedIndex = index;
      _answered = true;
    });
  }

  void _next() {
    if (_currentIndex < widget.wrongQuestions.length - 1) {
      setState(() {
        _currentIndex++;
        _selectedIndex = null;
        _answered = false;
      });
    } else {
      Navigator.pop(context);
    }
  }

  @override
  Widget build(BuildContext context) {
    final question = widget.wrongQuestions[_currentIndex];

    return Scaffold(
      appBar: AppBar(title: const Text("오답 복습")),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: QuestionCard(
          question: question,
          selectedIndex: _selectedIndex,
          answered: _answered,
          onSelect: _selectAnswer,
        ),
      ),
      floatingActionButton: _answered
          ? FloatingActionButton(
        onPressed: _next,
        child: const Icon(Icons.arrow_forward),
      )
          : null,
    );
  }
}