import 'package:flutter/material.dart';

class SettingsScreen extends StatefulWidget {
  final bool useTimer;

  const SettingsScreen({super.key, required this.useTimer});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late bool _useTimer;

  @override
  void initState() {
    super.initState();
    _useTimer = widget.useTimer;
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text("설정")),
      body: Padding(
        padding: const EdgeInsets.all(24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text("타이머 사용", style: TextStyle(fontSize: 18)),
            SwitchListTile(
              title: const Text("문제당 시간 제한 (20초)"),
              value: _useTimer,
              onChanged: (value) {
                setState(() {
                  _useTimer = value;
                });
              },
            ),
            const SizedBox(height: 30),
            Center(
              child: ElevatedButton.icon(
                icon: const Icon(Icons.check),
                label: const Text("저장 후 돌아가기"),
                onPressed: () {
                  Navigator.pop(context, _useTimer); // 설정된 값 반환
                },
              ),
            ),
          ],
        ),
      ),
    );
  }
}