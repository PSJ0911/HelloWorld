import 'package:flutter/material.dart';
import '../models/question.dart';

class QuestionCard extends StatelessWidget {
  final Question question;
  final int? selectedIndex;
  final bool answered;
  final void Function(int) onSelect;

  const QuestionCard({
    super.key,
    required this.question,
    required this.selectedIndex,
    required this.answered,
    required this.onSelect,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          question.text,
          style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
        ),
        const SizedBox(height: 20),
        ...List.generate(question.options.length, (index) {
          final isSelected = selectedIndex == index;
          final isCorrect = question.answerIndex == index;

          Color? color;
          if (answered) {
            if (isSelected && isCorrect) {
              color = Colors.green;
            } else if (isSelected && !isCorrect) {
              color = Colors.red;
            } else if (isCorrect) {
              color = Colors.green.withOpacity(0.5);
            }
          }

          return Container(
            margin: const EdgeInsets.symmetric(vertical: 6),
            child: ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: color ?? Colors.blue,
              ),
              onPressed: answered ? null : () => onSelect(index),
              child: Text(
                question.options[index],
                style: const TextStyle(
                  color: Colors.white,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ),
          );
        }),
        const SizedBox(height: 20),
        if (answered)
          Text(
            '💡 해설: ${question.explanation}',
            style: const TextStyle(fontSize: 16, color: Colors.black87),
          ),
      ],
    );
  }
}